<?php
include 'controller.php'; // ini dia ta koneksi dgn file controller.php

session_start();

// ini klo tekan tombol signup
if (isset($_POST['create'])) {
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  // ini for panggil fungsi createAccount dari controller
  if (createAccount($username, $email, $password)) {
    echo "";
  } else {
    echo "Gagal membuat akun.";
  }
}

if (isset($_POST['logout'])) {
  session_destroy(); // hapus sesi yang da login
  header("Location: login.php"); // balik ke halaman login
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weather Web - Sign Up</title>
  <link rel="stylesheet" href="signup.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
  <nav>
    <ul>
      <li><a href="index.html">Home</a></li>
      <li><a href="about.html">About Team</a></li>
      <?php
      if (isset($_SESSION['username'])) {
        // Jika pengguna telah login
        echo '<li><form action="" method="POST"><button type="submit" name="logout">Logout</button></form></li>';
      } else {
        // Jika pengguna belum login
        echo '<li><a href="login.php">Login</a></li>';
      }
      ?>
    </ul>
  </nav>

  <div class="wrapper">
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="container">
      <form action="" method="POST" class="signup-form">
        <h1>Sign Up</h1>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="create">Sign Up</button>
      </form>
      <p class="login-link">Already have an account? <a href="login.php">Login</a></p>
    </div>

    <script src="key.js"></script>
    <script src="script.js"></script>
</body>

</html>