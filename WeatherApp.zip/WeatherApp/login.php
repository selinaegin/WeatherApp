<?php
include 'controller.php'; 

session_start();

// Jika tombol "Login" diklik
if (isset($_POST['login'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  if (login($username, $password)) {
    // Login berhasil, arahkan ke halaman index.php
    $_SESSION['username'] = $username; // Simpan username dalam session
    header("Location: index.php");
    exit();
  } else {
    echo "Gagal login.";
  }
}

if (isset($_POST['logout'])) {
  session_destroy(); // hapus sesi yang da login
  header("Location: login.php"); // balik ke halaman login
  exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weather Web - Login</title>
  <link rel="stylesheet" href="login.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About Team</a></li>
      <?php
      if (isset($_SESSION['username'])) {
        // Jika pengguna telah login
        echo '<li><form action="" method="POST"><button type="submit" name="logout">Logout</button></form></li>';
      } else {
        // Jika pengguna belum login
        echo '<li><a href="login.php">Login</a></li>';
      }
      ?>
    </ul>
  </nav>
  <div class="wrapper">
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="container">
      <form action="login.php" method="POST" class="login-form">
        <h1>Login</h1>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="login">Login</button>
      </form>
      <p class="signup-link">Don't have an account? <a href="signup.php">Sign up</a></p>
    </div>
  </div>
  <!-- Script -->
  <script src="key.js"></script>
  <script src="script.js"></script>
</body>

</html>