<?php
include 'controller.php';

session_start();

if (isset($_POST['logout'])) {
  session_destroy(); // hapus sesi yang da login
  header("Location: login.php"); // balik ke halaman login
  exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Team - Weather App</title>
  <link rel="stylesheet" href="styleabout.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="#">About Team</a></li>
      <?php
      if (isset($_SESSION['username'])) {
        echo '<li><form action="" method="POST"><button type="submit" name="logout">Logout</button></form></li>';
      } else {
        echo '<li><a href="login.php">Login</a></li>';
      }
      ?>


    </ul>
  </nav>
  <div class="wrapper">
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="container">
      <h1>Meet Our Team</h1>
      <div class="team">
        <div class="team-member">
          <img src="/assets/selina.png" alt="Loindong Selina Regina" />
          <h3>Loindong Selina Regina</h3>
          <p>Member 1</p>
          <div class="social-media">
            <a href="https://instagram.com/yiann_nnn?igshid=YmMyMTA2M2Y="><i class="fab fa-instagram"></i></a>
          </div>
        </div>
        <div class="team-member">
          <img src="/assets/shintya.png" alt="Shintya Preity Aleng" />
          <h3>Shintya Preity Aleng</h3>
          <p>Member 2</p>
          <div class="social-media">
            <a href="https://instagram.com/shintyaaleng?igshid=YmMyMTA2M2Y="><i class="fab fa-instagram"></i></a>
          </div>
        </div>
        <div class="team-member">
          <img src="/assets/carda.png" alt="Carda Degi Vanki Likulangi" />
          <h3>Carda Degi Vanki Likulangi</h3>
          <p>Member 3</p>
          <div class="social-media">
            <a href="https://instagram.com/v_nnk.y?igshid=YmMyMTA2M2Y="><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Script -->
  <script src="key.js"></script>
  <script src="script.js"></script>
</body>
<footer>
  <div class="container">
    <a href="https://drive.google.com/drive/folders/1gtIJTJ4C857JuDHNC-4BsWYW8bVlu-6A?hl=id"><i class="fab fa-google-drive"></i> Google Drive</a>
  </div>
</footer>

</html>

