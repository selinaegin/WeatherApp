<?php
include 'koneksi.php'; // connect ke file koneksi.php for koneksi ke database

function createAccount($username, $email, $password)
{
  global $conn;

  $username = mysqli_real_escape_string($conn, $username);
  $email = mysqli_real_escape_string($conn, $email);
  $password = mysqli_real_escape_string($conn, $password);

  $existingUserQuery = "SELECT * FROM users WHERE username = '$username'";
  $existingUserResult = mysqli_query($conn, $existingUserQuery);

  if (mysqli_num_rows($existingUserResult) > 0) {
    return false;
  }

  $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

  $sql = "INSERT INTO users (username,email, password) VALUES ('$username','$email', '$hashedPassword')";

  if (mysqli_query($conn, $sql)) {
    return true;
  } else {
    echo "Error: " . mysqli_error($conn);
    return false;
  }
}

function login($username, $password)
{
  global $conn;

  $username = mysqli_real_escape_string($conn, $username);
  $password = mysqli_real_escape_string($conn, $password);

  $sql = "SELECT password FROM users WHERE username = '$username'";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $hashedPassword = $row['password'];

    if (password_verify($password, $hashedPassword)) {
      return true;
    }
  }

  return false; // Login gagal
}
