<?php
$host = "localhost";
$username = "root"; //kse sesuai dgn ngni punya, mar biasanya sih root
$password = ""; //ini juga biasanya kosong, mar klo ngni ad kse password, gnti ae
$database = "weatherweb"; //ini nama database, klo ngni pke yg kt dkse, nd prlu gnti ini

$conn = mysqli_connect($host, $username, $password, $database);

// Periksa koneksi
if (!$conn) {
  die("Koneksi gagal: " . mysqli_connect_error());
} else {
  echo "";
}
