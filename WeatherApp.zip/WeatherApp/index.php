<?php
include 'controller.php'; // ini dia ta koneksi dgn file controller.php

session_start();

if (isset($_POST['logout'])) {
  session_destroy(); // hapus sesi yang da login
  header("Location: login.php"); // balik ke halaman login
  exit();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Weather App</title>

  <link rel="stylesheet" href="style.css" />
</head>

<body>
  <nav>
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="about.php">About Team</a></li>
      <!-- //ini dpe tombol login mo brubah jdi logout klo user so login -->
      <?php
     if (isset($_SESSION['username'])) {
      echo '<li><form action="" method="POST"><button type="submit" name="logout">LOGOUT</button></form></li>';
    } else {
      echo '<li><a href="login.php">Login</a></li>';
    }

      ?>
    </ul>
  </nav>
  <div class="wrapper">
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="container">
      <div class="search-container">
        <input type="text" placeholder="Enter a city name" id="city" value="Manado" />
        <button id="search-btn">Search</button>
      </div>
      <div id="result"></div>
    </div>
  </div>
  <!-- Script -->
  <script src="key.js"></script>
  <script src="script.js"></script>
</body>

</html>