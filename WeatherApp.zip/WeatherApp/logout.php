<?php
session_start();
session_unset(); // Hapus semua variabel session
session_destroy(); // Hapus sesi
header("Location: login.php"); // Arahkan kembali ke halaman login
exit();

